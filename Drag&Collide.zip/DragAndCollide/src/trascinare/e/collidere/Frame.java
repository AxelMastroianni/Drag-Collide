package trascinare.e.collidere;

import javax.swing.JFrame;

public class Frame {

	public static void main(String[] args) {
		
		JFrame frame=new JFrame();
		frame.setSize(700,500);
		frame.setVisible(true);
		frame.setLocationRelativeTo(frame);
		Pannello myPanel=new Pannello();
		myPanel.setSize(frame.getSize());
		myPanel.setLayout(null);
		myPanel.setLocation(0,0);
		frame.add(myPanel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
