package trascinare.e.collidere;

import java.awt.Rectangle;

public class Ball extends Rectangle{
	private double x;
	private double y;
	private double vx;
	private double vy;
	private boolean xCollision;
	private boolean yCollision;
	private double radius;
	private double panelWidth;
	private double panelHeight;
	private int id;
	
	public Ball(double x, double y, double vx, double vy, double radius, double panelWidth, double panelHeight,
			int id) {
		this.x = x;
		this.y = y;
		this.vx = vx;
		this.vy = vy;
		this.radius = radius;
		this.panelWidth = panelWidth;
		this.panelHeight = panelHeight;
		this.id = id;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getVx() {
		return vx;
	}

	public void setVx(double vx) {
		this.vx = vx;
	}

	public double getVy() {
		return vy;
	}

	public void setVy(double vy) {
		this.vy = vy;
	}

	public boolean isxCollision() {
		return xCollision;
	}

	public void setxCollision(boolean xCollision) {
		this.xCollision = xCollision;
	}

	public boolean isyCollision() {
		return yCollision;
	}

	public void setyCollision(boolean yCollision) {
		this.yCollision = yCollision;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public double getPanelWidth() {
		return panelWidth;
	}

	public void setPanelWidth(double panelWidth) {
		this.panelWidth = panelWidth;
	}

	public double getPanelHeight() {
		return panelHeight;
	}

	public void setPanelHeight(double panelHeight) {
		this.panelHeight = panelHeight;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void move() {
		if(x<0 || x>panelWidth) {
			vx=-vx;
		}
		if(y<0 || y>panelHeight) {
			vy=-vy;
		}
		if(xCollision) {
			vx=-vx; //gli faccio cambiare direzione solo lungo la x
			//al massimo sposto i rettangoli
		}
		x+=vx;
		y+=vy;
		xCollision=false;
		yCollision=false;
	}
	
	public void interstects(Rectangle other) {
		if(this.intersects(other)) {
			xCollision=true;
		}
	}
	
	public boolean equals(Ball other) {
		if(id==other.getId())
			return true;
		return false;
	}

	
}
