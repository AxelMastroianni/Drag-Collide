package trascinare.e.collidere;

import java.awt.Color;
import java.awt.Rectangle;

public class Rettangolo extends Rectangle{
	
	private double x;
	private double y;
	private double base;
	private double altezza;
	public Rettangolo(double x, double y, double base, double altezza) {
		this.x = x;
		this.y = y;
		this.base = base;
		this.altezza = altezza;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public double getBase() {
		return base;
	}
	public void setBase(double base) {
		this.base = base;
	}
	public double getAltezza() {
		return altezza;
	}
	public void setAltezza(double altezza) {
		this.altezza = altezza;
	}

}
