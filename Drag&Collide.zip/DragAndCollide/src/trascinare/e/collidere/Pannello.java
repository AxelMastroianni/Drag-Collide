package trascinare.e.collidere;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Pannello extends JPanel implements MouseListener, MouseMotionListener, ActionListener {
	
	private ArrayList<Rettangolo> rettangoli=new ArrayList<>();
	private Timer t=new Timer(10,this);
	private Ball pallina;
	private boolean pallinaCreata=false;
	private int base;
	private int altezza;
	private final int basePartenza=10;
	private final int altezzaPartenza=20;
	
	public Pannello() {
		base=basePartenza;
		altezza=altezzaPartenza;
		t.start();
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		int i=0;
		super.paintComponent(g);
		Graphics2D g2=(Graphics2D)g;
		g2.setColor(Color.ORANGE);
		if(pallinaCreata) {
			g2.fillOval(0, 0, 50, 50);
		}
		g2.setColor(Color.RED);
		while(base<getWidth()-basePartenza) {
			if(altezza>getHeight()-altezzaPartenza) {
				altezza=altezzaPartenza;
				base+=basePartenza*2;
			}
			Rettangolo r=new Rettangolo(base,altezza,10,20);
			rettangoli.add(r);
			g2.fillRect(base, altezza,10,20);
			altezza+=altezzaPartenza*2;
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(pallinaCreata)
			pallina.move();
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(!pallinaCreata) {
			pallina=new Ball(0,0,2,3,50,getWidth(),getHeight(),0);
		}
		pallinaCreata=true;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
